package com.cg.client;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
@Table(name="Question_Master")
public class GearQuiz {
	
	@Id
	@GeneratedValue(strategy=GenerationType.AUTO)
	@Column(name="Ques_no")
	private int qNo;
	
	@Column(name="Ques_subtopic")
	private String qSubtopic;
	
	@Column(name="Ques_category")
	private String quesCat;
	
	@Column(name="Question")
	@NotEmpty(message="Question should not be Empty ,please enter value")
	private String ques;
	
	public String getQuesCat() {
		return quesCat;
	}
	public void setQuesCat(String quesCat) {
		this.quesCat = quesCat;
	}
	@Column(name="Option1")
	@NotEmpty(message="Option1 should not be Empty ,please enter value")
	private  String op1;
	
	@Column(name="Option2")
	@NotEmpty(message="Option2 should not be Empty ,please enter value")
	private  String op2;
	
	@Column(name="Option3")
	@NotEmpty(message="Option should not be Empty ,please enter value")
	private  String op3;
	
	@Column(name="Option4")
	@NotEmpty(message="Option should not be Empty ,please enter value")
	private  String op4;
	
	@Column(name="Answer")
	private  String ans;
	
	@Column(name="Remarks")
	private  String remark;
	
	@Column(name="Review_cnt")
	private int reviewCnt;
	
	
	public int getqNo() {
		return qNo;
	}
	public void setqNo(int qNo) {
		this.qNo = qNo;
	}
	@Override
	public String toString() {
		return "gearQuiz [qNo=" + qNo + ", qSubtopic=" + qSubtopic
				+ ", quesCat=" + quesCat + ", ques=" + ques + ", op1=" + op1
				+ ", op2=" + op2 + ", op3=" + op3 + ", op4=" + op4 + ", ans="
				+ ans + ", remark=" + remark + ", reviewCnt=" + reviewCnt + "]";
	}
	public String getqSubtopic() {
		return qSubtopic;
	}
	public void setqSubtopic(String qSubtopic) {
		this.qSubtopic = qSubtopic;
	}
	public String getQues() {
		return ques;
	}
	public void setQues(String ques) {
		this.ques = ques;
	}
	public String getOp1() {
		return op1;
	}
	public void setOp1(String op1) {
		this.op1 = op1;
	}
	public String getOp2() {
		return op2;
	}
	public void setOp2(String op2) {
		this.op2 = op2;
	}
	public String getOp3() {
		return op3;
	}
	public void setOp3(String op3) {
		this.op3 = op3;
	}
	public String getOp4() {
		return op4;
	}
	public void setOp4(String op4) {
		this.op4 = op4;
	}
	public String getAns() {
		return ans;
	}
	public void setAns(String ans) {
		this.ans = ans;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public int getReviewCnt() {
		return reviewCnt;
	}
	public void setReviewCnt(int reviewCnt) {
		this.reviewCnt = reviewCnt;
	}
	
}
