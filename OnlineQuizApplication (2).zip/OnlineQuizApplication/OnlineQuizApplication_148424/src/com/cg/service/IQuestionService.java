package com.cg.service;

import com.cg.client.GearQuiz;

public interface IQuestionService {
	public GearQuiz addQues(GearQuiz bean);
}
