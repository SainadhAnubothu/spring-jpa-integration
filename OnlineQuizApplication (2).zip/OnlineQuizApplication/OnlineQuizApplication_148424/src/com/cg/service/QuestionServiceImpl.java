package com.cg.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.client.GearQuiz;
import com.cg.dao.IQuestionDAO;
@Service("service")
public class QuestionServiceImpl implements IQuestionService{

	@Autowired
	IQuestionDAO dao;
	
	@Override
	public GearQuiz addQues(GearQuiz bean) {
		// TODO Auto-generated method stub
		return dao.addQues(bean);
	}

}
