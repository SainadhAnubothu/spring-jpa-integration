package com.cg.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.client.GearQuiz;

@Repository("dao")
@Transactional
public class QuestionDAOImpl implements IQuestionDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	@Override
	public GearQuiz addQues(GearQuiz bean) {
		// TODO Auto-generated method stub
		entityManager.persist(bean);
		entityManager.flush();
		return bean;
	}

	
}
